var searchData=
[
  ['poblacion',['Poblacion',['../class_poblacion.html#a7dc67d034b7c956eaf9fc4ceced981d1',1,'Poblacion::Poblacion(std::vector&lt; Transistor &gt; *transistors, std::vector&lt; Restriction &gt; *restrictions, std::vector&lt; unsigned &gt; *indxTransRestr)'],['../class_poblacion.html#a4b2335a88c50788cbd4d603158b98332',1,'Poblacion::Poblacion(const Poblacion &amp;orig)']]]
];
