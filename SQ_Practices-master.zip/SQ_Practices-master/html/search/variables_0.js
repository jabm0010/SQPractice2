var searchData=
[
  ['bound',['bound',['../struct_restriction.html#a4aebb8a3c8f031d52510028b65c8345a',1,'Restriction']]]
];
