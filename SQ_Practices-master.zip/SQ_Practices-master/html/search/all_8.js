var searchData=
[
  ['nrange_5f',['NRange_',['../class_transistor.html#a3bc69955c961d104f46b7d5dccf0c92d',1,'Transistor']]],
  ['numid_5f',['numID_',['../class_transistor.html#a52c1cb23ba419f11093e8c8c965aa99c',1,'Transistor']]]
];
