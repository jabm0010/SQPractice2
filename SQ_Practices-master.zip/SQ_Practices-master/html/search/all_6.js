var searchData=
[
  ['indexes_5f',['indexes_',['../class_especimen.html#a928ae8b5ab63aa4dc6323be1ee1e3940',1,'Especimen']]],
  ['indxtransrestr_5f',['indxTransRestr_',['../class_especimen.html#a7395c07987bfb83348429274db519a22',1,'Especimen::indxTransRestr_()'],['../class_poblacion.html#a05741cb302165060508d4240e77d8e9a',1,'Poblacion::indxTransRestr_()']]],
  ['iniciarpoblacion',['iniciarPoblacion',['../class_poblacion.html#aed93e35a79bb919656e8d2bf695e7b33',1,'Poblacion']]],
  ['interference',['interference',['../struct_restriction.html#af1299b2219474e8624570fdb954e3b25',1,'Restriction']]]
];
