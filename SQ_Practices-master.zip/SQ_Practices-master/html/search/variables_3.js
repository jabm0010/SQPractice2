var searchData=
[
  ['mejor_5f',['mejor_',['../class_poblacion.html#a46e470f699e09a7da15370a00056ec83',1,'Poblacion']]],
  ['mundo_5f',['mundo_',['../class_poblacion.html#a48d037a78e1c122d4f204e9e03709150',1,'Poblacion']]]
];
