var searchData=
[
  ['frecs_5f',['frecs_',['../class_transistor.html#a16353abffc883475f5063020dcecf727',1,'Transistor']]],
  ['freqs_5f',['freqs_',['../class_especimen.html#a116c86332f296fb755d20addcb112b3c',1,'Especimen']]]
];
