var searchData=
[
  ['restriction',['Restriction',['../struct_restriction.html',1,'']]]
];
