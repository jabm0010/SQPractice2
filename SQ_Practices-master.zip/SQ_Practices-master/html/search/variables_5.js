var searchData=
[
  ['restrictions_5f',['restrictions_',['../class_especimen.html#a645e708e47b36711f897649c9236768b',1,'Especimen::restrictions_()'],['../class_poblacion.html#a4b642f4a96881a9fcdae0197518672b2',1,'Poblacion::restrictions_()']]]
];
