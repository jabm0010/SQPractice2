var searchData=
[
  ['mutar',['mutar',['../class_especimen.html#af2b9b61f634d0db4fe5ece7a0b24dc22',1,'Especimen']]]
];
