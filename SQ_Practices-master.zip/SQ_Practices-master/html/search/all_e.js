var searchData=
[
  ['_7eespecimen',['~Especimen',['../class_especimen.html#a35a696f4e41c02ba7374d46fce599d03',1,'Especimen']]],
  ['_7epoblacion',['~Poblacion',['../class_poblacion.html#a3cbba0bfcded3815a977e36dbef72462',1,'Poblacion']]],
  ['_7etransistor',['~Transistor',['../class_transistor.html#a3d56d416d638012d82bb9974ed27bf6a',1,'Transistor']]]
];
