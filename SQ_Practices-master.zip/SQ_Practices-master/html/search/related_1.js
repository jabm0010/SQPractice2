var searchData=
[
  ['cruce2puntos',['cruce2Puntos',['../class_especimen.html#a8a4de450b2b1562e4c2142f36354665f',1,'Especimen']]],
  ['cruceblx',['cruceBlx',['../class_especimen.html#ac19b357cffe7f17903727df0157a7115',1,'Especimen']]]
];
