var searchData=
[
  ['bestfreq',['bestFreq',['../class_especimen.html#a482e88fc41a38f25c29e599591d54f71',1,'Especimen']]],
  ['bound',['bound',['../struct_restriction.html#a4aebb8a3c8f031d52510028b65c8345a',1,'Restriction']]],
  ['busquedalineal',['busquedaLineal',['../_algoritmos_geneticos_8cpp.html#a395691afb70f651e64e8cb8343ef9fd7',1,'AlgoritmosGeneticos.cpp']]]
];
