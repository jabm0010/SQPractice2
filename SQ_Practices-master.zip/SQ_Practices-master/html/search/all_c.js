var searchData=
[
  ['scanval',['scanVal',['../class_especimen.html#adafd385909bf0c50a7a47b56a80574b2',1,'Especimen']]],
  ['setfrecs',['setFrecs',['../class_transistor.html#a0de31976edba3bff508b0a976581f769',1,'Transistor']]],
  ['sigval',['sigVal',['../class_especimen.html#a069f88d12bc8279b1ba55be7766fee34',1,'Especimen']]]
];
