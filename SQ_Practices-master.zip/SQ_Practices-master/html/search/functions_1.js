var searchData=
[
  ['bestfreq',['bestFreq',['../class_especimen.html#a482e88fc41a38f25c29e599591d54f71',1,'Especimen']]],
  ['busquedalineal',['busquedaLineal',['../_algoritmos_geneticos_8cpp.html#a395691afb70f651e64e8cb8343ef9fd7',1,'AlgoritmosGeneticos.cpp']]]
];
