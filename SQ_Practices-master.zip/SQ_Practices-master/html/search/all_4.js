var searchData=
[
  ['frangeparse',['FRangeParse',['../class_parser.html#a02269fd7ede45418f21110169dffafe3',1,'Parser']]],
  ['frecs_5f',['frecs_',['../class_transistor.html#a16353abffc883475f5063020dcecf727',1,'Transistor']]],
  ['freqs_5f',['freqs_',['../class_especimen.html#a116c86332f296fb755d20addcb112b3c',1,'Especimen']]],
  ['fullbestfreq',['fullBestFreq',['../class_especimen.html#abeecd7a51eee9b7991355ad8c64a6653',1,'Especimen']]],
  ['fullcalccost',['fullCalcCost',['../class_especimen.html#a4217d9a2fa42490b991ce288b896e537',1,'Especimen']]],
  ['fullgreedinit',['fullGreedInit',['../class_especimen.html#aa16d00022bc5868d3e72178d1e761eb5',1,'Especimen']]]
];
