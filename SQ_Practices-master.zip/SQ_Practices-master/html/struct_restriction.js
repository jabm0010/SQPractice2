var struct_restriction =
[
    [ "bound", "struct_restriction.html#a4aebb8a3c8f031d52510028b65c8345a", null ],
    [ "interference", "struct_restriction.html#af1299b2219474e8624570fdb954e3b25", null ],
    [ "trans1", "struct_restriction.html#a92e87eed3a46f266cbcfe400152aba94", null ],
    [ "trans2", "struct_restriction.html#aa118bbea202cd2044ea9feefc1c50453", null ]
];