var class_transistor =
[
    [ "Transistor", "class_transistor.html#a28c7f5a49c3711f60095bd574005f8e1", null ],
    [ "~Transistor", "class_transistor.html#a3d56d416d638012d82bb9974ed27bf6a", null ],
    [ "getFreqRange", "class_transistor.html#a412454c62abf00b4cd1d404bbca3168f", null ],
    [ "getNRange", "class_transistor.html#acf22e4ee548ebadc5c5f5fabeae8f369", null ],
    [ "getNumID", "class_transistor.html#ac64c27bdde9c51cf92f78c46dca43fc1", null ],
    [ "getRandFrec", "class_transistor.html#a253248b2b1c8514a5515c579113e23bc", null ],
    [ "operator[]", "class_transistor.html#a33a6614df982763754804a461232d07f", null ],
    [ "setFrecs", "class_transistor.html#a0de31976edba3bff508b0a976581f769", null ],
    [ "frecs_", "class_transistor.html#a16353abffc883475f5063020dcecf727", null ],
    [ "NRange_", "class_transistor.html#a3bc69955c961d104f46b7d5dccf0c92d", null ],
    [ "numID_", "class_transistor.html#a52c1cb23ba419f11093e8c8c965aa99c", null ]
];