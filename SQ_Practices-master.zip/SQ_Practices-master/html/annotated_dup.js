var annotated_dup =
[
    [ "Especimen", "class_especimen.html", "class_especimen" ],
    [ "Parser", "class_parser.html", "class_parser" ],
    [ "Poblacion", "class_poblacion.html", "class_poblacion" ],
    [ "Restriction", "struct_restriction.html", "struct_restriction" ],
    [ "Transistor", "class_transistor.html", "class_transistor" ]
];